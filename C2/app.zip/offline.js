﻿{
	"version": 1528232296,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"c2webappstart.js",
		"images/fond.png",
		"images/balle-sheet0.png",
		"images/j1-sheet0.png",
		"images/deadzone.png",
		"images/gameover-sheet0.png",
		"images/centre-sheet0.png",
		"images/lignebord-sheet0.png",
		"images/j1up-sheet0.png",
		"images/j1down-sheet0.png",
		"images/j2up-sheet0.png",
		"images/j2down-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}